public class Runner10 {
    public static void main(String[] args) {

        // passing value of static data members
        Calculator.a =45;
        Calculator.b = 30;

        // Calling methods without creating objects
        Calculator.sum();
        Calculator.multiply();
        Calculator.divide();
        Calculator.modulus();
        Calculator.sin();
        Calculator.cos();
        Calculator.tan();


    }
}
