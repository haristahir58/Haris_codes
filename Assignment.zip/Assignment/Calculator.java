public class Calculator {
    public static double a;
    public static double b;

    public static void sum(){
        double sum = a+b;
        System.out.println("The Sum of "+ a +" and " + b +" will be: " + sum);
    }
    public static void  multiply(){
        double multiply = a*b;
        System.out.println("The multiplication of "+ a + " and " + b + " will be: " + multiply);
    }
    public static void divide() {
        double divide = a / b;
        System.out.println("The division of "+ a +" and " + b + " will be: " + divide);
    }
    public static void modulus (){
        double modulus = a % b;
        System.out.println("The modulus of "+ a +" and " + b +" will be: " + modulus);
    }

    public static void sin (){
        double sin_a = Math.sin(a);
        double sin_b = Math.sin(b);
        System.out.println("The sin of "+ a +" will be : " + sin_a);
        System.out.println("The sin of "+ b +" will be : " + sin_b);
    }

    public static void cos(){
        double cos_a = Math.cos(a);
        double cos_b = Math.cos(b);
        System.out.println("The cosine of "+ a +" will be : " + cos_a);
        System.out.println("The cosine of "+ b +" will be : " + cos_b);
    }

    public static void tan (){
        double tan_a = Math.tan(a);
        double tan_b = Math.tan(b);
        System.out.println("The tangent of "+ a +" will be : " + tan_a);
        System.out.println("The tangent of "+ b +" will be : " + tan_b);
    }



}
