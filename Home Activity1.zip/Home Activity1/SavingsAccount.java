public class SavingsAccount {
    private static double annualInterestRate;
    private double savingsBalance;


    public SavingsAccount()
    {
        savingsBalance = 0;
        annualInterestRate = 0;
    }

    public SavingsAccount(double balance)
    {
        this.savingsBalance = balance;
        annualInterestRate = 0;
    }

    public void calculateMonthlyInterest()
    {
        double monthlyI;
        monthlyI= (double)(this.savingsBalance*annualInterestRate/12);
        this.savingsBalance+=monthlyI;
    }

    public static void modifyInterestRate(double newAnnualInterestRate)
    {
        annualInterestRate = newAnnualInterestRate;
    }

    public double getSavingsBalance()
    {
        return savingsBalance;
    }






}
