public interface Shape {

    //Creating method area in Interface

    public double area();

}
