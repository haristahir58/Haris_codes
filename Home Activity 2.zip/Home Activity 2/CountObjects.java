public class CountObjects {

    private static int object_count = 0;
    private static int d;
    public CountObjects(){
        object_count++;

    }
    public CountObjects(int object){
        d = object;
        object_count++;
    }
    public static int Total_objects() {
        return object_count;

    }
    }
